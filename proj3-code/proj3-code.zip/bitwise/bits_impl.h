// DO NOT MODIFY THIS FILE
int isZero(int);
int bitNor(int, int);
int distinctNegation(int);
int dividePower2(int, int);
int getByte(int, int);
int isPositive(int);
unsigned floatNegate(unsigned);
int isLessOrEqual(int, int);
int bitMask(int, int);
int addOK(int, int);
unsigned floatScale64(unsigned);
unsigned floatPower2(int);
// DO NOT MODIFY THIS FILE
